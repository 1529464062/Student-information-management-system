﻿function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}
window.onload = function() {
    //判断UserFlag是否存在
    if (GetQueryString("UserFlag") && GetQueryString("UserName")) {
        if (GetQueryString("UserFlag") == "0") {
            document.getElementById("UserName").innerHTML = "[学生]" + GetQueryString("UserName");
        } else {
            if (GetQueryString("UserFlag") == "1") {
                document.getElementById("UserName").innerHTML = "[管理员]" + GetQueryString("UserName");
            }
        }
        for (var i = 0; i < document.getElementById("nav_dot").getElementsByTagName("li").length; i++) {
            if (document.getElementById("nav_dot").getElementsByTagName("li")[i].getAttribute("data-userflag") != "") {
                if (document.getElementById("nav_dot").getElementsByTagName("li")[i].getAttribute("data-userflag") != GetQueryString("UserFlag")) {
                    document.getElementById("nav_dot").getElementsByTagName("li")[i].style.display = "none";
                }
            }
            for (var j = 0; j < document.getElementById("nav_dot").getElementsByTagName("li")[i].getElementsByTagName("a").length; j++) {
                if (document.getElementById("nav_dot").getElementsByTagName("li")[i].getElementsByTagName("a")[j].getAttribute("data-userflag") != "") {
                    if (document.getElementById("nav_dot").getElementsByTagName("li")[i].getElementsByTagName("a")[j].getAttribute("data-userflag") != GetQueryString("UserFlag")) {
                        document.getElementById("nav_dot").getElementsByTagName("li")[i].getElementsByTagName("a")[j].style.display = "none";
                    }
                }
            }
        }
        //点击修改密码
        document.getElementById("updatePassword_Control").addEventListener("click", function() {
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">修改密码</a></li></ul>";
            //显示密码修改页面
            //将站点地图改为密码修改
        });
        //点击退出按钮
        document.getElementById("exit").addEventListener("click", function() {
            //跳转到登录页
            location.href = "../login.html";
        });
        //点击设置按钮
        document.getElementById("Set").addEventListener("click", function() {
            //将站点地图改为设置
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">设置</a></li></ul>";

        });
        //<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">系统公告</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">最新公告</a></li></ul>;
        //点击学生信息录入
        document.getElementById("studentInfoInsert_Control").addEventListener("click", function() {
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">学生管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">学生信息录入</a></li></ul>";
        });
        //点击学生信息查询
        document.getElementById("studentInfoSelectList_Control").addEventListener("click", function() {
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">学生管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">学生信息查询</a></li></ul>";
        });
        //点击学生信息查看
        document.getElementById("studentInfoSelect_Control").addEventListener("click", function() {
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">学生管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">学生信息查看</a></li></ul>";
        });
        //点击课程信息添加
        document.getElementById("CourseInfoAdd_Control").addEventListener("click", function() {
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">课程管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">课程信息添加</a></li></ul>";
        });
        //点击课程信息管理
        document.getElementById("CourseInfoManager_Control").addEventListener("click", function() {
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">课程管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">课程信息管理</a></li></ul>";
        });
        //点击课程成绩录入
        document.getElementById("CourseInfoInsert_Control").addEventListener("click", function() {
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">课程管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">课程成绩录入</a></li></ul>";
        });
        //点击学生选择课程
        document.getElementById("StudentCourseChoice_Control").addEventListener("click", function() {
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">课程管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">学生选择课程</a></li></ul>";
        });
        //点击学生成绩查询
        document.getElementById("StudentCourseResultQuery_Control").addEventListener("click", function() {
            document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">课程管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">学生成绩查询</a></li></ul>";
        });
        //点击新闻通知发布
        document.getElementById("NewsRelease_Control").addEventListener("click", function() {
        document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">通知管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">新闻通知发布</a></li></ul>";
        });
        //点击新闻列表
        document.getElementById("NewsList_Control").addEventListener("click", function() {
        document.getElementById("siteMap").innerHTML = "<ul><li><img src=\"../IMG/home.png\"></li><li style=\"margin-left: 25px;\">您当前的位置：</li><li><a href=\"javascript:void(0)\">通知管理</a></li><li>&gt;</li><li><a href=\"javascript:void(0)\">新闻列表</a></li></ul>";
        });

    } else {
        //跳转到错误页
        alert("数据未找到");
    }

}